package cn.movieshop.bilibilifans;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.widget.RemoteViews;

import com.yanzhenjie.nohttp.NoHttp;
import com.yanzhenjie.nohttp.RequestMethod;
import com.yanzhenjie.nohttp.rest.OnResponseListener;
import com.yanzhenjie.nohttp.rest.Request;
import com.yanzhenjie.nohttp.rest.RequestQueue;
import com.yanzhenjie.nohttp.rest.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class BiliBiliWidgetService extends Service {

    private static final String TAG = "BiliBiliWidgetService";
    public static final String ACTION_UPDATE = "fans_action_update";

    public BiliBiliWidgetService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel("id","name", NotificationManager.IMPORTANCE_LOW);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(channel);
        Notification notification = new Notification.Builder(getApplicationContext(),"id").build();
        startForeground(1, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String action = intent.getAction();

        if (!TextUtils.isEmpty(action)){
            switch (action){
                case ACTION_UPDATE:
                    //更新某个widget
                    int[] updates = intent.getIntArrayExtra("appWidgetIds");
                    if (updates!=null&&updates.length>0){
                        for (int appWidgetId :
                                updates) {
                            updateWidget(appWidgetId);
                        }
                    }
                    break;
            }
        }
        return START_NOT_STICKY;

    }


    private void updateWidget(final int appWidgetId) {
        Log.d(TAG, "updateWidget...");
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Log.d(TAG, "task run...");
                getFans(appWidgetId);
            }
        };
        timer.schedule(task,300,5000);
    }

    private void getFans(final int id) {
        RequestQueue queue = NoHttp.newRequestQueue();
        String url = "https://api.bilibili.com/x/relation/stat?vmid=122879&jsonp=jsonp&callback=__jp3";
        Request<String> request = NoHttp.createStringRequest(url, RequestMethod.GET);
        request.addHeader("Referer","https://space.bilibili.com/122879/");
        queue.add(0, request, new OnResponseListener<String>() {
            @Override
            public void onStart(int what) {
                Log.d(TAG, "getFans onStart, what:" + what);
            }

            @Override
            public void onSucceed(int what, Response<String> response) {
                Log.d(TAG, "getFans onSucceed :" + what + " " + response.get());
                if (response.responseCode() == 200) {
                    String result = response.get();
                    String res = result.replace("__jp3(","").replace("(","").replace(")","");
                    String follower = "0";
                    try {
                        JSONObject jsonObject = new JSONObject(res);
                        follower = jsonObject.getJSONObject("data").getString("follower");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Log.d(TAG, "getFans onSucceed, follower:" + follower);
                    AppWidgetManager manager = AppWidgetManager.getInstance(getApplicationContext());
                    AppWidgetProviderInfo appWidgetInfo = manager.getAppWidgetInfo(id);
                    RemoteViews remoteViews = new RemoteViews(getPackageName(),R.layout.bili_bili_app_widget);
                    remoteViews.setTextViewText(R.id.appwidget_text,"Fans: " + follower);
                    manager.updateAppWidget(id,remoteViews);
                }
            }

            @Override
            public void onFailed(int what, Response<String> response) {
                Log.e(TAG, "getFans onFailed :" + what + " " + response.get());
            }

            @Override
            public void onFinish(int what) {
                Log.d(TAG, "getFans onFinish :" + what);
            }
        });
    }

}
